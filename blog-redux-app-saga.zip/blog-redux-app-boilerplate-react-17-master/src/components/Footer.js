import React from 'react'

const Footer = () => {
  return (
    <div>Copyright 2022</div>
  )
}

export default Footer